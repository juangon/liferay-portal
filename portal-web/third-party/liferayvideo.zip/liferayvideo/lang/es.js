CKEDITOR.plugins.setLang( 'liferayvideo', 'es', {
	toolbar	: 'Liferay video',
	dialogTitle : 'Propiedades de video de Liferay',
	fakeObject : 'Video',
	properties : 'Editar el video',
	widthRequired : 'La anchura no se puede dejar en blanco',
	heightRequired : 'La altura no se puede dejar en blanco',
	poster: 'Video de Liferay'
});
