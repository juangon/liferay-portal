CKEDITOR.plugins.setLang( 'liferayvideo', 'en', {
	toolbar	: 'Liferay video',
	dialogTitle : 'Liferay video properties',
	fakeObject : 'Video',
	properties : 'Edit video',
	widthRequired : 'Width field cannot be empty',
	heightRequired : 'Height field cannot be empty',
	poster: 'Liferay video'
});
