AUI Image Viewer
========

@VERSION@
------
	* #AUI-1106 - Image Viewer Gallery styling issues
